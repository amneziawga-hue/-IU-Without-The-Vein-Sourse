package org.iuaddons.nosurfacedeposits;

import net.minecraftforge.fml.common.Mod;

@Mod(
    modid = "iu_no_surface_deposits",
    name = "IU No Surface Deposits",
    version = "1.0.0",
    dependencies = "required-after:industrialupgrade@[3.3.0.47,3.3.0.48)"
)
public final class AddonEntrypoint {
}
