package org.iuaddons.nosurfacedeposits;

import net.minecraft.launchwrapper.IClassTransformer;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

/** Removes only ore-deposit surface placements from Industrial Upgrade 3.3.0.47. */
public final class DepositFilterTransformer implements IClassTransformer, Opcodes {
    private static final String TARGET = "com.denfop.world.vein.AlgorithmVein";
    private static final String GENERATE = "generate";
    private static final String GENERATE_DESC = "(Lnet/minecraft/world/World;Lcom/denfop/world/vein/VeinType;Lnet/minecraft/util/math/BlockPos;" +
        "Lnet/minecraft/world/chunk/Chunk;ILnet/minecraft/world/chunk/IChunkProvider;" +
        "Lnet/minecraft/world/gen/IChunkGenerator;)V";
    private static final String SETTER = "setBlockState1";
    private static final String SETTER_DESC = "(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;" +
        "Lnet/minecraft/block/state/IBlockState;I)Z";
    private static final String DEPOSIT_STATE_DESC = "(I)Lnet/minecraft/block/state/IBlockState;";
    private static final String[] DEPOSIT_BLOCKS = new String[] {
        "com/denfop/blocks/BlockDeposits",
        "com/denfop/blocks/BlockDeposits1",
        "com/denfop/blocks/BlockDeposits2"
    };
    private static final int EXPECTED_DEPOSIT_CALLS = 9;

    @Override
    public byte[] transform(String name, String transformedName, byte[] basicClass) {
        String actualName = transformedName != null ? transformedName : name;
        if (!TARGET.equals(actualName) || basicClass == null) {
            return basicClass;
        }

        ClassReader reader = new ClassReader(basicClass);
        ClassWriter writer = new ClassWriter(reader, 0);
        final int[] generateMethods = new int[] {0};
        final int[] depositGetters = new int[] {0};
        final int[] replacedCalls = new int[] {0};

        ClassVisitor visitor = new ClassVisitor(ASM5, writer) {
            @Override
            public MethodVisitor visitMethod(int access, String methodName, String descriptor,
                                            String signature, String[] exceptions) {
                MethodVisitor output = super.visitMethod(access, methodName, descriptor, signature, exceptions);
                if (!GENERATE.equals(methodName) || !GENERATE_DESC.equals(descriptor)) {
                    return output;
                }
                generateMethods[0]++;
                return new MethodVisitor(ASM5, output) {
                    private boolean depositGetterSeen;
                    private boolean depositFlagSeen;

                    @Override
                    public void visitInsn(int opcode) {
                        if (depositGetterSeen) {
                            depositGetterSeen = false;
                            depositFlagSeen = opcode == ICONST_3;
                        }
                        super.visitInsn(opcode);
                    }

                    @Override
                    public void visitMethodInsn(int opcode, String owner, String calledName,
                                                String calledDescriptor, boolean isInterface) {
                        boolean depositGetter = "getStateMeta".equals(calledName)
                            && DEPOSIT_STATE_DESC.equals(calledDescriptor)
                            && isDepositBlock(owner);
                        if (depositGetter) {
                            depositGetters[0]++;
                            depositGetterSeen = true;
                            depositFlagSeen = false;
                            super.visitMethodInsn(opcode, owner, calledName, calledDescriptor, isInterface);
                            return;
                        }

                        boolean depositPlacement = opcode == INVOKESTATIC
                            && TARGET.replace('.', '/').equals(owner)
                            && SETTER.equals(calledName)
                            && SETTER_DESC.equals(calledDescriptor)
                            && depositFlagSeen;
                        depositGetterSeen = false;
                        depositFlagSeen = false;
                        if (depositPlacement) {
                            // The original stack is [world, position, depositState, flags].
                            // Pop those four one-slot values and push false for the caller's POP.
                            // This is byte-for-byte the same length as the 3-byte INVOKESTATIC,
                            // so existing jump offsets and stack-map frames remain unchanged.
                            super.visitInsn(POP2);
                            super.visitInsn(POP2);
                            super.visitInsn(ICONST_0);
                            replacedCalls[0]++;
                            return;
                        }
                        super.visitMethodInsn(opcode, owner, calledName, calledDescriptor, isInterface);
                    }

                    private boolean isDepositBlock(String owner) {
                        for (String block : DEPOSIT_BLOCKS) {
                            if (block.equals(owner)) return true;
                        }
                        return false;
                    }
                };
            }
        };

        reader.accept(visitor, 0);
        if (generateMethods[0] != 1) {
            throw new IllegalStateException("Unsupported Industrial Upgrade build: expected one " +
                TARGET + ".generate" + GENERATE_DESC + ", found " + generateMethods[0]);
        }
        if (depositGetters[0] != EXPECTED_DEPOSIT_CALLS) {
            throw new IllegalStateException("Unsupported Industrial Upgrade build: expected " +
                EXPECTED_DEPOSIT_CALLS + " surface-deposit state lookups, found " + depositGetters[0]);
        }
        if (replacedCalls[0] == 0) {
            // A pre-patched copy contains the lookups but no calls to place those blocks.
            System.out.println("[IU No Surface Deposits] Surface-deposit placements are already suppressed.");
            return basicClass;
        }
        if (replacedCalls[0] != EXPECTED_DEPOSIT_CALLS) {
            throw new IllegalStateException("Refusing partial patch: filtered " + replacedCalls[0] +
                " of " + EXPECTED_DEPOSIT_CALLS + " surface-deposit calls");
        }
        System.out.println("[IU No Surface Deposits] Suppressed " + replacedCalls[0] +
            " surface-deposit placements; ore generation remains enabled.");
        return writer.toByteArray();
    }
}
